//
//  main.c
//  Neverint
//
//  Created by choi hyunill on 2016. 10. 24..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
        int  category, used, season, elec, tax;
        double total;
        printf("일반용=1 산업용=2  ");
        scanf("%d", &category);
        if (category = 1)
        {
            printf("사용량을 입력하세요(kw): ");
            scanf("%d", &used);
            
            if (used <= 100)
            elec = 370 + used * 52;
            
            else if (used <= 200)
            elec = 660 + used * 88.5;
            
            else if (used <= 300)
            elec = 1130 + used * 127.8;
            
            else if (used <= 400)
            elec = 2710 + used * 184.3;
            
            else if (used <= 500)
            elec = 5130 + used * 274.3;
            
            else
            elec = 9330 + used * 494;
        }
        else if (category = 2)
        {
            printf("봄=1 여름=2 가을=3 겨울=4");
            scanf("%d", &season);
            
            if (season = 1)
            {
                printf("사용량을 입력하세요(kw): ");
                scanf("%d", &used);
                elec = 5550 + used*59.2;
            }
            else if (season = 2)
            {
                printf("사용량을 입력하세요(kw): ");
                scanf("%d", &used);
                elec = 5550 + used * 81;
            }
            else if (season = 3)
            {
                printf("사용량을 입력하세요(kw): ");
                scanf("%d", &used);
                elec = 5550 + used*59.2;
            }
            else if (season = 4)
            {
                printf("사용량을 입력하세요(kw): ");
                scanf("%d", &used);
                elec = 5550 + used*79.3;
            }
            else
            printf("잘못입력했어요\n");
        }
        else {
            printf("잘못입력했어요\n");
        }
        tax = elec*0.09;
        total = elec + tax;
        
        printf("총 전기요금은%d입니다\n", total);
        return 0;
    }
