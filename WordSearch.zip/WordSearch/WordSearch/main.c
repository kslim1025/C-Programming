//
//  main.c
//  WordSearch
//
//  Created by choi hyunill on 2016. 10. 7..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#include <stdio.h>
#include <string.h>

int main(int argc, const char * argv[]) {
    char search[100]; //검색할 단어들
    char word[100];   //파일에서 검색될 비교할 단어
    
    int i,k,h;
    int j=0;
    FILE *fin1,*fin2,*fin3,*fin4,*fin5,*fin6,*fin7,*fin8,*fin9,*fin10;
    //불러올 파일들
    
    fin1= fopen("A01.txt","r");
    fin2= fopen("A02.txt","r");
    fin3= fopen("A03.txt","r");
    fin4= fopen("A04.txt","r");
    fin5= fopen("A05.txt","r");
    fin6= fopen("A06.txt","r");
    fin7= fopen("A07.txt","r");
    fin8= fopen("A08.txt","r");
    fin9= fopen("A09.txt","r");
    fin10= fopen("A10.txt","r");

    printf("Search for word on the text\n");
    scanf("%s",&search); //검색할 단어의 길이 조사.
    k=strlen(search);
    printf("===============================");
    printf("%s의  검색 결과입니다.\n",search);
    printf("===============================");
    while(fscanf(fin1,"%s",word)!=EOF) //a01.text에서 검색
    {
        h=strlen(word);
        if(h>=k) //검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
        {
            for(i=0;i<k;i++)
            {
                if(search[i]==word[i])
                    j=j+1;
            }
        }
        if(j==k)
            printf("%s\n",word);
    }
    while( fscanf( fin2,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin3,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin4,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin5,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin6,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin7,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin8,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin9,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
     while( fscanf( fin10,"%s", word ) != EOF )//a01.txt에서 검색
         {
             h=strlen(word);
             j=0;
             if(h>=k)//검색할 단어의 길이가 파일에 있는 단어길이보다 작을때
                 {
                      for(i=0;i<k;i++)
                          {
                               if(search[i]==word[i])
                                   j=j+1;
                              }
                     }
             if(j==k)
                 printf("%s\n",word);
             }
}

