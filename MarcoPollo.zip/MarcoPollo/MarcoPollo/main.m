//
//  main.m
//  MarcoPollo
//
//  Created by choi hyunill on 2016. 11. 9..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
