
public class ArrayUtility {
	static public int[] transInt;
	static public double[] transDouble;

	static double[] intToDouble(int[] source) {
		transDouble = new double[source.length];
		for (int i = 0; i < source.length; i++) {
			transDouble[i] = source[i];
		}
		return transDouble;
	}

	static int[] doubleToInt(double[] source) {
		transInt = new int[source.length];
		for (int i = 0; i < source.length; i++) {
			transInt[i] = (int) source[i];
		}
		return transInt;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int examInt[] = { 1, 2, 3, 4, 5 };
		double examDouble[] = { 1.2, 2.2, 3.3, 4.4, 5.5 };

		double res_Double[] = ArrayUtility.intToDouble(examInt);
		int res_int[] = ArrayUtility.doubleToInt(examDouble);

		System.out.println("int type change to Doulbe type: ");
		for (int i = 0; i < res_Double.length; i++) {
			System.out.println(res_Double[i] + "\t");
		}

		System.out.println("Double type change to Int: ");
		for (int i = 0; i < res_int.length; i++) {
			System.out.println(res_int + "\t");
		}
	}

}
