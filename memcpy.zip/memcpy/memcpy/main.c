//
//  main.c
//  memcpy
//
//  Created by choi hyunill on 2016. 9. 20..
//  Copyright © 2016년 choi hyunill. All rights reserved.
//

#include <stdio.h>
#include <string.h>
int main(int argc, const char * argv[]) {
    char Love[10]={"ILoveYou"};
    char Hate[10]={"IHateYou"};

    char Love_1[10]={"ILoveYou"};
    char Hate_1[10]={"IHateYou"};
    
    printf("(memcpy)복사전 Love 배열 =%s\n",Love);
    printf("(memcpy)복사전 Hate 배열 =%s\n",Hate);
    printf("\n");
    memcpy(Love+1,Hate+1,4);
    
    printf("(memcpy)복사후 Love 배열 =%s\n",Love);
    printf("(memcpy)복사후 Hate 배열 =%s\n",Hate);
    printf("\n");
    
    printf("(memcpy)복사전 Love_1 배열 =%s\n",Love_1);
    printf("(memcpy)복사전 Hate_1 배열 =%s\n",Hate_1);
    printf("\n");
    memcpy(Love_1+1,Hate_1+1,4);
    
    printf("(memcpy)복사후 Love_1 배열 =%s\n",Love_1);
    printf("(memcpy)복사후 Hate_1 배열 =%s\n",Hate_1);
    printf("\n");
    
}
