//
//  main.c
//  hash
//
//  Created by kslim1025 on 2016. 9. 3..
//  Copyright © 2016년 heap. All rights reserved.
//
#include <iostram.h>
#include <stdio.h>

#ifndef __HASHGENERALCONTAINER_H_
#define __HASHGENERALCONTAINER_H_ //이 안에 들어있는 코드는 한번만 읽혀진다.
#endif


//Container를 위해 Index를 채워놓고 비어있는 Index를 쉽게 접근하기 위한 Index할당 템플릿이다.
//TIndexType으로는 short나 int 같은 signed형으로 들어가야한다.
//Data를 사용할때마다 RefCount를 Check 할 수 있도록 하였다.

#if _USEHASH_STR_WSTRING
typedef std::wstring T_HASHSTRING;
#else
typedef std::string T_HASHSTRING;
#endif
template <typename TIndexType,typename THashKey, typename TDataType>
class THashGeneralContainer
{
public:
    THashHeneralContainer(void)
    :m_ptFreeIndexLinker(0)
    ,m_paData(0)
    ,m_tMaxDataSize(0)
    ,m_tCurDataNum(0)
    ,m_tFreeIndicator(-1)
    ,m_cUseRefcount(true) //Default로 Refcount를 사용한다. 이값이 false 라는 Refturn값이 있어도 Data를 해제한다.
    {
    }
    //한가지Type으로만 이루어진 Container이다. Refcount　사용여부를 같이 설정한다. Default로 사용
    THashGeneralContainer(TIndexType tMaxSize, bool bUseRefCount=true)
    :m_ptFreeIndexLinker(0)
    ,m_paData(0)
    ,m_tMaxDataSize(0)
    ,m_tFreeIndicator(-1)
    {
        m_cUseRefcount =bUseRefCount;
        SetContainer(tMaxSize);
    }
    virtual ~THashGeneralContainer(void)
    {
        if(m_ptFreeIndexLinker)
        {
            if(m_ptFreeIndexLinker)
            {
                delete[] m_ptFreeIndexLinker;
                m_ptFreeIndexLinker=0;
            }
            m_ptFreeIndexLinker=0;
            m_tMaxFataSize=0;
            m_tFreeIndicator=-1;
            m_tCurDataNum= 0;
        }
        if(m_paData)
        {
            delte[] m_paData;
            m_paData=0;
        }
    }
    //Container를 설정한다. 정상적인 설정이 이루어졌다면 tMaxSize값이 Return 된다.
    TIndexType SetContainer(TIndexType tMaxSize)
    {
        if(m_ptFreeIndexLinker || m_tFreeIndicator != -1 || m_tMaxDataSize > 0||m_paData)
            return -1;
        if(tMaxSize <=0)
            return -2;
        m_ptFreeIndexLinker = new TIndexType[tMaxSize];
        if(!m_paData)
        {
            delete[] m_ptFreeIndexLinker;
            m_ptFreeIndexLinker=0;
            return -3;
        }
        m_tMaxDataSize=tMaxSize;
        TIndexType tIndexCnt;
        for(tIndexCnt =0;tIndexCnt<tMaxSize;tIndexCnt++)
        {
            m_ptFreeIndexLinker[tIndexCnt]=tIndexCnt -1;
        }
        m_ptFreeIndexLinker[0]=0;
        m_tFreeIndicator = tMaxSize-1;
        m_tMaxDataSize =tMaxSize;
        m_tCurDataNum=0;
        return tMaxSize;
    }
    TIndexType FreeData(THashKey tHashKey, bool bIngroRefCnt =false)
    {
        stdext::hash_map < THashKey, TIndexType >::iterator itrFind= m_HashData.find(tHashKey);
        if(itrFind != m_HashData.end())
        {
            m_HashData/erase(itFind);
            return FreeDataFromIndex(itrFind->second,bIngroRefCnt);
        }
        return -1;
    }
    // 해당 index 의 할당 되어 있는 Index를 해제한다.
    // return : -10 인덱스가 Container 범위가 아니다.
    //        : -11 RefCount가 있어서 헤제가 불가능
    //        : -20 할당되어 있지 않은데 해제하려한다. 해당 Index를 비운다.
    // m_cUseRefcount가 true일 경우 reference Count가 있으면 해제 실패
    // false일 경우 강제 해제
    // bIngroRefCnt 값은 m_cUseRefcount가 True 일 경우만 유효하다.
    // bIngroRefCnt true이면 Refcount가 있어도 강제 해제
    // false 이면 Refcount가 있으면 -11 return
    TIndexType FreeDataFromIndex(TIndexType tIndex, bool bIngroRefCnt=false)
    {
        if(!tIndex<0||tIndex>=m_tMaxDataSize)
            return -10;
        
        TIndexType tIndexData = m_ptFreeIndexLinker[tIndex];
        //RefCount가 있어 사용중이므로 해제 불가능하다.
        if(tIndexData<-1&& m_cUseRefcount && !bIngroRefCnt)
        {
            return -11;
        }
        //할당도 되어있지 않은 데이터를 Free Data를 하려한다. 이련경우 가져다 쓴느 데에서 오류 체크 할 수 있도록 반환해준다.
        else if(tIndexData>-1)
        {
            return -20;
        }
        //할당되어 있는 Data를 반환한다.
        else{
            //비어있는 공간이 없을 때 현재 Index를 지시하도록 한다.
            if(m_tFreeIndicator<0)
            {
                m_ptFreeIndexLinker[tIndex]=tIndex;
                m_tFreeIndicator = tIndex;
            }
            else{
                m_ptFreeIndexLinker[tIndex]=m_tFreeIndicator;
                m_tFreeIndicator= tIndex;
            }
            m_tCurDataNum--;
            return tIndex;
        }
        return -1;
    }
    //RefCount를 하나 감소 시킨 후 현재 참조되어 있는 RefCOunt를 반환하다.
    //return-10; Container Index 범위를 벗어났다. -11: RefCount 증가없이 할당만 되어 있는 것을 Release Data 하려고 한다.
    //-20: 할당 되어 있지 않은 Data를 Release Data 하려한다. 0보다 크거나 같으면; 남아있는 RefCOunt
    TIndexType ReleaseData(TIndexType tIndex)
    {
        //Index가 Container범위를 벗어났다.
        if(tIndex<0||tIndex>=m_tMaxDataSize)
            return -10;
        TIndexType tIndexData= m_ptFreeIndexLinker[tIndex];
        //Ref Count 를 하나 감소시킨다.
        if(tIndexData < -1)
        {
            tIndexData++;
            m_ptFreeIndexLinker[tIndex]=tIndexData;
            return(-tIndexData -1);
        }
        //할당만 되어 있는 것을 Release Data하려고 한다. 이런경우 가져다 쓰는 데에서 오류체크 할 수 있도록 반환해준다.
        else if(tIndexData == -1)
        {
            return -11;
        }
        //할당도 되어있지 않은 데이터를  Release Data하려고한다. 이런경우 가져다 쓰는 데에서 오류 체크할 수 있도록 반환해준다.
        else if(tIndexData>-1)
        {
            return -20;
        }
        return -1;
    }
    //Data가 없으면 0보다 작은 값을 Data가 존재하면 Reference Count를 반환
    TIndexType GetRefCnt(TIndexType tIndex)
    {
        if(tIndex<0||tIndex>=m_tMaxDataSize)
            return -10;
        TIndexType tIndexData = m_ptFreeIndexLinker[tIndex];
        if(tIndexData>-1)
        {
            return -1;
        }
        retirn -tIndexData -1;
    }
    TDataType* GetDataFromIndex(TIndexType tIndex)
    {
        if(tIndex<0 || tIndex >= m_tMaxDataSize)
            return NULL;
        TIndexType tIndexData = m_ptFreeIndexLinker[Index];
        if(tIndexData>-1)
        {
            return NULL;
        }
        m_ptFreeIndexLinker[tIndex]--;
        return m_paData[Index];
    }
    TDataType* GetDataFromHashKey(THashKey& tKey)
    {
        stdext::hash_map < THashKey, TIndex>::iterator itrFind = m_HashData.find(Key);
        if(itrFInd != m_HashData.end())
            }
    return GetDataFromIndex(itrFind->second);
}
return 0;
}
TDataType* AllcData(THashKey& tKey)
{
    TdataType* pExistData=GetDataFromHashKey(tKey);
    if(pExistData)
    {
        return 0;
    }
    if(m_tFreeIndicator<0)
    {
        return 0;
    }
    //정상 상태라면 이럴일이 ㅇ벗기 때문에 패스
    if(m_tFreeIndicator >= m_tMaxDataSize)
    {
        return -10;
        TIndexType tCurrentIndex=m_tFreeIndicator;
        TIndexType tNextIndex = m_ptFreeIndexLiner[tCurrentIndex];
        m_ptFreeIndexLinker[tCurrentIndex]=-1;
        //현재 마지막 비어있는 곳이 였을 경우
        if(tNextIndex == tCurrentIndex)
        {
            m_tFreeIndicator=-1;
        }
        else{
            m_tFreeIndicator=tNextIndex;
        }
        m_tCurDataNum++;
        std::pair<stdext::hash_map < THashKey, TIndexType>::iterator, BOOL>ret = m_HashData.insert(stdext::hashmap<THashKey, TIndexType>::value_type(tKey,tCurrentIndex));
        _ASSERT(ret.second);
        return &(m_paData[tCurrentIndex]);
    }
    TIndexType GetMaxDataNum(void)
    {
        return m_tMaxDataSize;
    }
    virtual TindexType GetCurrentDataNum(void)
    {
        return m_tCurrentDataNum;
    }
    virtual TIndexType GetEmptySize(void)
    {
        return m_tMaxDataSize - m_tCurDataNum;
    }
    
    bool m_cUseRefcount;
    TIndexType m_tMaxDataSize;
    TindexType m_FreeIndicator;
    TIndexType m_tCurDataNum;
    
    stdex::hash_map<THashKey, TIndexType> m_HashData;
    TIndexTYpe* m_ptFreeIndexLinker;
    TDataType* m_paData;
};
#endif// _HASHGENERALCONTAINER_H
int main(int argc, const char * argv[]) {
    
}
