//
//  main.cpp
//  MyString
//
//  Created by choi hyunill on 2016. 10. 11..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#include "HMystring.h"

using namespace std;
int main(int argc, const char * argv[]) {

        cout << "#default constructor." << endl;
        MyString default_Constructor;
        default_Constructor.show();
        cout << endl;
        
        cout << "#constructor from char." << endl;
        MyString char_Constructor("String constructed from char.");
        char_Constructor.show();
        cout << endl;
        
        cout << "#copy constructor." << endl;
        MyString test_String("I am string for copy constructor.");
        MyString copy_Constructor(test_String);
        copy_Constructor.show();
        cout << endl;
        
        cout << "#Assignment(=)." << endl;
        MyString source_String("Source String.");
        MyString dest_String = source_String;
        dest_String.show();
        cout << endl;
        
        cout << "#Append(+=)." << endl;
        MyString current_String("I am current String.");
        MyString appending("I am appending tail.");
        current_String.show();
        appending.show();
        current_String.operator+=(appending);
        current_String.show();
        cout << endl;
        
        cout << "#operator(+)." << endl;
        MyString add_String1("First String.");
        MyString add_String2("Second String.");
        add_String1.show();
        MyString add_Result = add_String1 + add_String2;
        add_Result.show();
        cout << endl;
        
        cout << "#operator(==)." << endl;
        MyString equal_String1("Equal.");
        MyString equal_String2("Equal.");
        MyString not_Equal_String("Not Equal.");
        
        equal_String1.show();
        equal_String2.show();
        if(equal_String1 == equal_String2)
            cout << "Two Strings are Equal." << endl;
        cout << endl;
        
        cout << "#operator(!=)." << endl;
        equal_String1.show();
        not_Equal_String.show();
        if(equal_String1.operator!=( not_Equal_String))
            cout << "Two Strings are NOT Equal." << endl;
        cout << endl;
        
        
        cout << "#index(int)." << endl;
        MyString indexing_String("String for indexing test.");
        indexing_String.show();
        cout << "index : 3" << endl;
        cout << indexing_String.operator[](3) << endl;
        cout << endl;
        
        cout << "#leng()." << endl;
        MyString length_String("String for length() function.");
        length_String.show();
        cout << "The length of the string is :" << length_String.leng() << endl;
        cout << endl;
        
        cout << "#subString(int, int)." << endl;
        MyString sub_String("String for subString function.");
        sub_String.show();
        sub_String.subString(7, 12);
        cout << endl;
        
        system("pause");
        return 0;
    }
