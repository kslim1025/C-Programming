//
//  HMystring.cpp
//  MyString
//
//  Created by choi hyunill on 2016. 10. 11..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#include "HMystring.h"

using namespace std;

//Default constructor
MyString::MyString()
{
    //constructor
    mstr = new char[1];
    mstr[0] = 0;
    mlen = 0;
}

//Constuctor from char
MyString::MyString(const char *str)
{
    char mlen = strlen(str);
    mstr = new char[mlen + 1];
    strcpy(mstr, str);
}

//Copy Constructor
MyString::MyString(const MyString &obj)
{
    mlen = obj.mlen;
    mstr = new char[mlen + 1];
    strcpy(mstr, obj.mstr);
}

//Destructor
MyString::~MyString()
{
    delete []mstr;
    mstr = NULL;
}

//Assignment
MyString& MyString::operator=(const MyString &obj)
{
    return MyString(obj);
}

//Append another MyString to current MyString

MyString& MyString::operator+=(const MyString &obj)
{
    mlen += obj.mlen;
    char *tempstr = new char[mlen];
    
    strcpy(tempstr,mstr);
    strcat(tempstr,obj.mstr);
    
    if(mstr!=NULL)
        delete []mstr;
    mstr=tempstr;
    
    return *this;
}



//Compose two MyString together

MyString operator+(const MyString &obj,const MyString &obj1)
{
    int len = obj.mlen + obj1.mlen + 1;
    char* buffstr = new char[len + 1];
    
    strcpy(buffstr,obj.mstr);
    strcat(buffstr,obj1.mstr);
    buffstr[len] = '\0';
    
    MyString buff(buffstr);
    
    delete []buffstr;
    return buff;
}

//Compare two MyString
bool MyString::operator==(const MyString &str)const
{
    if(strcmp(mstr, str.mstr))
        return false;
    return true;
}

//Not equal
bool MyString::operator!=(const MyString &str)const
{
    if(strcmp(mstr, str.mstr))
        return true;
    return false;
}



//overload operator []
char MyString::operator[](int index)
{
    return mstr[index-1];
}

//overload operator <<
ostream& operator<<(ostream &os,const MyString &obj)
{
    os << obj.mstr;
    return os;
}

//overload operator >>
istream& operator>>(istream &is, MyString &obj)
{
    char str[100];
    is >> str;
    obj = MyString(str);
    return is;
}

//Return the length of the string
int MyString::leng()const
{
    return mlen;
}

//Get the sub-string from the posistion and the length is len
void MyString::subString(int position,int len)
{
    char* tempstr = new char[len + 1];
    for(int i = 0; i < len; i++)
    {
        tempstr[i] = mstr[position + i];
    }
    tempstr[len] = '\0';
    cout << tempstr << endl;
}

