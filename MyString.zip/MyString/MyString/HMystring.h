//
//  HMystring.h
//  MyString
//
//  Created by choi hyunill on 2016. 10. 11..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#ifndef HMystring_h
#define HMystring_h


#endif /* HMystring_h */

#include <iostream>
#include <cstring>
#include <stdio.h>
using namespace std;

class MyString{
public:
    //Default constructor
    MyString();
    
    //Constuctor from char
    MyString(const char *str);
    
    //Destructor
    ~MyString();
    
    //Copy Constructor
    MyString(const MyString &obj);
    
    //Assignment
    MyString &operator=(const MyString &obj);
    
public:
    
    //Append another MyString to current MyString
    MyString &operator+=(const MyString &obj);
    
    //Compose two MyString together
    friend MyString operator+(const MyString &obj,const MyString &obj1);
    
    //Compare two MyString
    bool operator==(const MyString &str)const;
    
    //Not equal
    bool operator!=(const MyString &str)const;
    
    //overload operator []
    char operator[](int index);
    
    //overload operator <<
    friend ostream &operator<<(ostream &os,const MyString &obj);
    
    //overload operator >>
    friend istream &operator>>(istream &is, MyString &obj);
    
    
    //Return the length of the string
    int leng()const;
    
    //Get the sub-string from the posistion and the length is len
    void subString(int position,int len);
    
private:
    
    char *mstr;
    int mlen;
    
public:
    void show()
    {
        cout << mstr << endl;
        cout << "The length of the string is  " << mlen << endl;
    }
};

#endif /* HMystring_hpp */
