//
//  main.c
//  mallocCallocFree
//
//  Created by choi hyunill on 2016. 9. 20..
//  Copyright © 2016년 choi hyunill. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

void function(int);

int main(int argc, const char * argv[]) {
    int m=0;
    fputs("배열의 크기를 입력하세요.",stdout);
    scanf("%d",&m);
    function(m);
    return 0;
}

void function(int i)
{
    //int array[i]; //잘못된 배열 선언
    int* array=(int*)malloc(sizeof(int)*i);
    int j;
    if(array == NULL)
    {
        puts("메모리 할당에 실패");
        exit(1);
    }
    //동적 할당한 메모리 사용
    for(j=0;j<i;j++)
        array[j]=j+1;
    
    for(j=0;j<i; j++)
        printf("%d",array[i]);
    
    printf("\n");
    free(array); //할당된 메모리 소멸
}

//메모리의 3가지 영역
//1. 데이터영역
//2. 힙영역
//3. 스택영역
