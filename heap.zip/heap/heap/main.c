//
//  main.c
//  heap
//
//  Created by kslim1025 on 2016. 9. 1..
//  Copyright © 2016년 heap. All rights reserved.
//

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    int i, aSize;
    int *randomNums;
    
    time_t t;
    
    double total=0;
    int biggest,smallest;
    float average;
    
    srand(time(&t));
    
    printf("How many 'rand' do you wanna use?");
    scanf("%d",&aSize);
    
    randomNums =(int*)malloc(aSize * sizeof(int));
    
    if(!randomNums)
    {
        printf("we cannot assign this srand");
        exit(1);
    }
    for(i=0;i<aSize;i++){
        randomNums[i]=(rand() % 500)+1;
    }
    
    biggest =0;
    smallest=500;
    
    for(i=0; i<aSize; i++)
    {
        total = total+randomNums[i];
        if(randomNums[i]>biggest)
        {
            biggest =randomNums[i];
        }
        else if(randomNums[i]<smallest)
        {
            smallest =randomNums[i];
        }
    }
    average= ((float)total)/((float)aSize);
    
    printf("최대값은 %d \n",biggest);
    printf("최소값은 %d \n",smallest);
    printf("평균값은 %.2f\n",average);
    
    free(randomNums);
    return 0;
}
