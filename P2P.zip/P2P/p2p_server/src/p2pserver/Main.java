package p2pserver;

import java.lang.Thread.State;

import peers.PeerManager;

public class Main {
	private static Listener mListener = null;
	private static Console mConsole = null;
	
	public static void endWork() {
		mConsole.setRunning(false);
		mListener.setRunning(false);
		for (int i = 0; i < PeerManager.size(); i++)
			PeerManager.get(i).setRunning(false);
		mListener.close();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("P2P Server v1.0 - 8조\n");
		
		int port;
		try { port = Integer.parseInt(args[1]); } catch (Exception e) { port = 9090; }
		
		Console.openLogger();
		
		mListener = new Listener(port);
		mConsole = new Console();

		while  (mListener.getState() != State.RUNNABLE);
		mConsole.setCanRead(true);
		
	}

}
