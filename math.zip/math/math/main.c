//
//  main.c
//  math
//
//  Created by kslim1025 on 2016. 8. 26..
//  Copyright © 2016년 kslim1025. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("수학 숙제할 시간입니다.");
    
    printf("\n\n 섹션1 : 제곱근\n");
    printf("49.0의 제곱근은 %.1f\n입니다.",sqrt(49.0));
    printf("149.0의 제곱근은 %.1f\n입니다.",sqrt(149.0));
    printf("0.149의 제곱근은 %.2f\n입니다.",sqrt(0.149));
    
    printf("\n\n 섹션2 : 지수\n");
    printf("4의 3승은 %.1f\n",pow(4.0,3.0));
    printf("7의 5승은 %.1f\n",pow(7.0,5.0));
    printf("34의 1/2승은 %.1f\n",pow(34.0,0.5));

    printf("\n\n 섹션3 : 삼각함수\n");
    printf("60도의 코사인값은 %.3f\n",cos((60*(3.141519/180.0))));
    printf("60도의 사인값은 %.3f\n",sin((60*(3.141519/180.0))));
    printf("60도의 탄젠트값은 %.3f\n",tan((60*(3.141519/180.0))));
    printf("45도의 아크코사인값은 %.3f\n",acos((45*(3.141519/180.0))));
    printf("30도의 아크사인값은 %.3f\n",asin((30*(3.141519/180.0))));
    printf("15도의 아크탄젠트값은 %.3f\n",atan((15*(3.141519/180.0))));
    
    printf("\n\n섹션4 : 로그함수\n");
    printf("e의 2승은 %3.f\n", exp(2));
    printf("5의 자연로그값은 %3.f\n", log(5));
    printf("5의 상용로그값은 %3.f\n", log10(5));
    
    return 0;
    
    

}
