//
//  main.c
//  memSet
//
//  Created by kslim1025 on 2016. 9. 19..
//  Copyright © 2016년 hashTest. All rights reserved.
//

#include <stdio.h>
#include <memory.h>

int main(int argc, const char * argv[]) {
    char love[10]={"ILOVEYOU"};
    
    printf("memset() 사용이전 love = %s\n",love);
    
    memset(love + 1,'*',4);
    printf("memset()을 사용한 후의 love =%s\n",love);
    
    return 0;
}
