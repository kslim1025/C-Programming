#if !defined(AFX_PROGRESSWND_H__F2166A80_0AA3_11D5_A480_00105A84B4E0__INCLUDED_)
#define AFX_PROGRESSWND_H__F2166A80_0AA3_11D5_A480_00105A84B4E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProgressWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProgressWnd window

class CProgressWnd : public CWnd
{
// Construction
public:
	CProgressWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgressWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProgressWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CProgressWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGRESSWND_H__F2166A80_0AA3_11D5_A480_00105A84B4E0__INCLUDED_)
