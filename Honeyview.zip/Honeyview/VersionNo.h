

#define FILEVER        1.0.0.703
#define PRODUCTVER     1.0.0.703
#define STRFILEVER     "1. 0. 0. 703\0"
#define STRPRODUCTVER  "1. 0. 0. 703\0" 
