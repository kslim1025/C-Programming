

#include "stdafx.h"
#include "Global.h"
#include "Option.h"


COption	g_Option;