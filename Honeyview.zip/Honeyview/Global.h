
#pragma once

class COption;

extern COption	g_Option;

