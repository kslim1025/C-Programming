//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HoneyView.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_HONEYVTYPE                  129
#define IDD_OPTION                      130
#define IDD_SELECTPAGE                  131
#define IDC_CHECK_STRETCH               1000
#define IDC_CHECK_INTERPOLATION         1001
#define IDC_LIST_FILES                  1001
#define IDC_CHECK_VIEW2PAGE             1002
#define IDC_APPNAME                     1002
#define IDC_CHECK_FLIPPAGE              1003
#define IDC_EDIT_HELP                   1003
#define IDC_CHECK_CACHENEXTPAGE         1004
#define IDC_CHECK_AUTODETECTWIDTH       1005
#define IDC_CHECK_SHARPEN               1006
#define IDM_FILE_NEXT                   32771
#define IDM_SETTING_OPTION              32772
#define IDM_FILE_PREV                   32773
#define IDM_VIEW_FULLSCREEN             32774
#define IDM_OPEN_FOLDER                 32779
#define IDM_OPEN_FILE                   32780
#define IDM_PREV10                      32781
#define IDM_PREV                        32782
#define IDM_NEXT                        32783
#define IDM_NEXT10                      32784
#define IDM_FLIPPAGE                    32785
#define IDM_SHOW2PAGE                   32786
#define IDM_INTERPOLATION               32787
#define ID_BUTTON32788                  32788
#define IDM_STRETCHING                  32789
#define IDM_SHOWFILES                   32790
#define IDM_SELECTPAGE                  32791
#define IDM_OPEN_PCO                    32792
#define IDM_SHARPEN                     32793
#define IDM_ROTATE                      32794
#define ID_INDICATOR_PAGEINFO           61204
#define ID_INDICATOR_PROGRESS           61205
#define IDS_VERSION                     61206

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32795
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
