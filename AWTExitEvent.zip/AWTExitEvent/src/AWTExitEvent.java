import java.awt.*;
import java.awt.event.*;

public class AWTExitEvent 
{
	public static void main(String args[])
	{
		Frame frm = new Frame("AWTFrame");
		frm.setBounds(130,200,400,100);
		frm.setLayout(new FlowLayout());
		
		WindowListener listen= new WindowAdapter()
		{
			public void windowClosing(WindowEvent ev)
			{
				System.exit(0); //프로그램 종료 명령
			}
		};
		frm.addWindowListener(listen);
		
		Button btn1=new Button("My Button1");
		Button btn2=new Button("My Button2");
		Button btn3=new Button("My Button3");
		Button btn4=new Button("My Button4");
		
		frm.add(btn1);
		frm.add(btn2);
		frm.add(btn3);
		frm.add(btn4);
		frm.setVisible(true);
	}
}
