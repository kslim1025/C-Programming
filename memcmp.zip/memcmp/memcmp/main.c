//
//  main.c
//  memcmp
//
//  Created by kslim1025 on 2016. 9. 19..
//  Copyright © 2016년 hashTest. All rights reserved.
//

#include <stdio.h>
#include <string.h>

void printResult(int result);

int main(int argc, const char * argv[]) {
    char me[10]={"ILoveYou"};
    char you[10]={"YouLoveMe"};
    
    printf("me=%s\n",me);
    printf("you=%s\n",you);
    
    printf("\nLove와Love의 비교 =>\n");
    int result=memcmp(me+1,you+3,4);
    printResult(result);
    
    printf("\nLoveY와LoveM의 비교 =>\n");
    result = memcmp(me+1,you+3,5);
    printResult(result);
    
    printf("\n");
    return 0;
}

void printResult(int result)
{
    switch(result)
    {
        case 0:
            printf("비교 결과 해당 메모리가 같다\n");
            break;
        case 1:
            printf("비교 결과 첫번쨰 메모리가 더 크다\n");
            break;
        case -1:
            printf("first memory small than others\n");
            break;
            
    }
}
