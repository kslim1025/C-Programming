class CPoint{
	int a,b;
	String c;
	
	public CPoint(int a, int b)
	{
		this.a=a;
		this.b=b;
	}
	
	public void show()
	{
		if(c==null)
		{
			System.out.println("("+a+","+b+")");
		}
		else
		{
			System.out.println("("+a+","+b+")");
		}

	}
	public String toString()
	{
		return "("+a+"，"+b+")"+"입니다";
	}
}
	class CColorPoint extends CPoint{
		public CColorPoint(int a, int b, String c)
		{
			super(a,b);
			this.c =c;
		}
		public void show()
		{
			super.show();
		}
	}

public class CCPoint {
	public static void main(String args[])
	{
		CPoint a,b;
		
		a= new CPoint(2,3);
		b= new CColorPoint(3,4,"red");
		a.show();
		b.show();
		System.out.println(a);
		System.out.println(b);
		
	}
}
