#ifndef AUDIO_H
#define AUDIO_H

int start_audio(char *peer, char *port);

#endif /* AUDIO_H */
