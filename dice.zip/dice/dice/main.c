//
//  main.c
//  dice
//
//  Created by kslim1025 on 2016. 8. 26..
//  Copyright © 2016년 kslim1025. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdlib.h>


int main(int argc, const char * argv[]) {
    // insert code here...
    int dice1,dice2;    //주사위 게임을 위한 주사위 2개를 생성
    int total1,total2;
    
    time_t t;
    char ans;
    
    srand(time(&t));
    
    dice1 = (rand() % 5) + 1;
    dice2 = (rand() % 5) + 1;
    total1 = dice1+dice2;
    
    printf("첫번째 주사위의 굴리기는  %d와%d",dice1,dice2);
    printf("총합은 %d\n\n\n",total1);
    
    do{
        puts("다음번의 주사위는 어떻게 될까요?");
        puts("(H)igher,(L)ower, or (S)ame\n");
        puts("H,L,S중의 하나를 입력하시오");
        
        scanf("%c", &ans);
        ans=toupper(ans);
    }while((ans!='H')&& (ans!='L')&&(ans!='S'));
    
    dice1 =(rand() % 5)+1;
    dice2 =(rand() % 5)+1;
    total2 = dice1 + dice2;
    
    printf("\n두번째 주사위는 %d와 %d",dice1,dice2);
    printf("총합은 %d\n\n",total2);
    
    if(ans=='L')
    {
        if(total2<total1)
        {
            printf("잘했습니다! 맞았어요.\n");
            printf("%d은 %d보다 낮습니다.\n",total1,total2);
        }
    else
    {
        printf("미안합니다. %d은 %d보다 낮지 않네요",total2,total1);
    }
  }
    else if(ans=='H')
    {
        if(total2 >total1)
        {
            printf("잘했습니다! 맞았어요.\n");
            printf("%d은 %d보다 높습니다.\n",total1,total2);
        }
        else
        {
            printf("미안합니다! %d은 %d보다 높지않네요.",total2,total1);
        }
    }
    else if(ans=='S')
    {
        if(total2 == total1)
        {
            printf("잘했습니다! 맞았어요.\n");
            printf("%d은 %d보다 같습니다.\n",total1,total2);
        }
        else
        {
            printf("미안합니다! %d은 %d보다 같지않네요.",total2,total1);
        }
    }
    return 0;
}
